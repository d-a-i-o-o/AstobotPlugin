import asyncio
import aiohttp
from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api.star import Context, Star, register
from astrbot.api import logger
import astrbot.api.message_components as Comp

@register("AstobotPlugin", "d-a-i-o-o", "AstobotPlugin 插件", "1.0.0")
class MyPlugin(Star):
    LOLICON_API = "https://api.lolicon.app/setu/v2"

    def __init__(self, context: Context):
        super().__init__(context)

    async def initialize(self):
        """可选择实现异步的插件初始化方法，当实例化该插件类之后会自动调用该方法。"""

    # 注册指令的装饰器。指令名为 helloworld。注册成功后，发送 `/helloworld` 就会触发这个指令，并回复 `你好, {user_name}!`
    @filter.command("helloworld")
    async def helloworld(self, event: AstrMessageEvent):
        """这是一个 hello world 指令""" # 这是 handler 的描述，将会被解析方便用户了解插件内容。建议填写。
        user_name = event.get_sender_name()
        message_str = event.message_str # 用户发的纯文本消息字符串
        message_chain = event.get_messages() # 用户所发的消息的消息链 # from astrbot.api.message_components import *
        logger.info(message_chain)
        yield event.plain_result(f"Hello, {user_name}, 你发了 {message_str}!") # 发送一条纯文本消息

    @filter.command("hahaha")
    async def hahaha(
        self,
        event: AstrMessageEvent,
        r18: int = 0,
        num: int = 1,
        uid: str = "",
        keyword: str = "",
        tag: str = "",
        size: str = "original",
        proxy: str = "",
        dateAfter: int = 0,
        dateBefore: int = 0,
        dsc: bool = False,
        excludeAI: bool = False,
        aspectRatio: str = "",
    ):
        """获取图片；参数按 Lolicon API 顺序填写，均为可选。"""
        try:
            params, preferred_sizes = self._build_hahaha_params(
                r18, num, uid, keyword, tag, size, proxy,
                dateAfter, dateBefore, dsc, excludeAI, aspectRatio,
            )
            timeout = aiohttp.ClientTimeout(total=15)
            async with aiohttp.ClientSession(
                timeout=timeout,
                trust_env=True,
                headers={"User-Agent": "AstrBot-AstobotPlugin/1.0"},
            ) as session:
                async with session.get(
                    self.LOLICON_API,
                    params=params,
                ) as response:
                    response.raise_for_status()
                    payload = await response.json(content_type=None)

            if not isinstance(payload, dict):
                raise ValueError("API 返回的数据格式不正确")
            if payload.get("error"):
                raise ValueError(str(payload["error"]))

            data = payload.get("data")
            if not isinstance(data, list) or not data:
                raise ValueError("API 未返回图片数据")
            image = data[0]
            urls = image.get("urls", {}) if isinstance(image, dict) else {}
            image_url = next(
                (urls.get(size) for size in preferred_sizes if isinstance(urls, dict) and urls.get(size)),
                urls.get("original") if isinstance(urls, dict) else None,
            )
            if not isinstance(image_url, str) or not image_url.startswith(("http://", "https://")):
                raise ValueError("API 返回的图片链接无效")

            yield event.image_result(image_url)
        except (aiohttp.ClientError, aiohttp.ContentTypeError, asyncio.TimeoutError) as exc:
            logger.warning(f"hahaha 指令请求 Lolicon API 失败: {exc}")
            yield event.plain_result("获取图片失败，请稍后再试。")
        except (ValueError, KeyError, TypeError) as exc:
            logger.warning(f"hahaha 指令解析 API 响应失败: {exc}")
            yield event.plain_result("图片服务返回了无效数据，请稍后再试。")

    @staticmethod
    def _build_hahaha_params(r18, num, uid, keyword, tag, size, proxy,
                             dateAfter, dateBefore, dsc, excludeAI, aspectRatio):
        """将自动解析的参数转换为 API 查询参数。"""
        params: list[tuple[str, object]] = [
            ("r18", r18), ("num", num), ("dsc", dsc), ("excludeAI", excludeAI),
        ]
        for name, value in (("keyword", keyword), ("proxy", proxy), ("aspectRatio", aspectRatio)):
            if value:
                params.append((name, value))
        for name in ("dateAfter", "dateBefore"):
            value = locals()[name]
            if value:
                params.append((name, value))
        for name, value in (("uid", uid), ("tag", tag), ("size", size)):
            for item in str(value).split(","):
                if item.strip():
                    params.append((name, int(item) if name == "uid" else item.strip()))
        return params, [x.strip() for x in str(size).split(",") if x.strip()]

    async def terminate(self):
        """可选择实现异步的插件销毁方法，当插件被卸载/停用时会调用。"""
