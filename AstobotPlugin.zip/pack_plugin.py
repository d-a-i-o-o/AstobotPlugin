#!/usr/bin/env python3
"""将当前目录压缩为 AstrBot 插件 ZIP 包。"""

from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "AstobotPlugin.zip"
EXCLUDED_DIRS = {".git", "__pycache__"}

with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as archive:
    for path in ROOT.rglob("*"):
        if not path.is_file() or path == OUTPUT:
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if path.suffix.lower() in {".pyc", ".pyo"} or path.suffix.lower() == ".zip":
            continue
        archive.write(path, relative.as_posix())

print(f"已压缩：{OUTPUT}")
